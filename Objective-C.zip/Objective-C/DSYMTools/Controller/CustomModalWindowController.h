//
//  CustomModalWindowViewController.h
//  CustomModalWindow
//
//  Created by Nick Kuh on 16/01/2015.
//  Copyright (c) 2015 Mumbo Apps Ltd. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface CustomModalWindowController : NSWindowController

@end
